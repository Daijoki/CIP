# Dark Mode - Quick Testing Checklist

Use this checklist to quickly verify dark mode is working correctly in both tools.

## ✅ Initial Visual Check (30 seconds)

### Both Tools
- [ ] Toggle button appears in top-right corner of header
- [ ] Toggle shows moon icon (for light mode) initially
- [ ] Clicking toggle switches theme immediately
- [ ] Icon changes to sun (for dark mode)
- [ ] No flash or jarring transitions
- [ ] Background turns dark slate blue (#0F172A)
- [ ] Text turns light (#F1F5F9)

## ✅ Component Spot Checks (2 minutes)

### Navigation & Header
- [ ] Header gradient still visible and attractive
- [ ] Navigation tabs are readable
- [ ] Active tab is clearly distinguished
- [ ] Hover states work properly

### Cards & Content
- [ ] Feature cards on overview page are readable
- [ ] Card borders are visible but subtle
- [ ] Text on cards has good contrast
- [ ] Icons/gradients look professional

### Interactive Elements
- [ ] Buttons are clearly visible
- [ ] Hover effects work
- [ ] Focus indicators show on keyboard navigation
- [ ] Links are distinguishable

## ✅ Persistence Check (30 seconds)
- [ ] Refresh page - dark mode stays
- [ ] Close tab, reopen - preference remembered
- [ ] Toggle to light, refresh - stays light
- [ ] Toggle back to dark - saves correctly

## ✅ Section Quick Tests (3 minutes)

### Documents Section
- [ ] Document list is readable
- [ ] Individual doc pages work in dark mode
- [ ] Modal overlays have proper contrast

### Glossary
- [ ] Term list is readable
- [ ] Search box works and is visible
- [ ] Study mode/flashcards look good

### Historical Foundations
- [ ] Timeline is visible and readable
- [ ] Case details are clear
- [ ] Modals work properly

### Quiz
- [ ] Questions are readable
- [ ] Answer choices are clear
- [ ] Results page works

## ✅ Mobile Check (1 minute)
- [ ] Toggle button doesn't overlap title on mobile
- [ ] All text is readable on small screens
- [ ] Touch target is adequate (can tap toggle)
- [ ] Navigation works on mobile

## ✅ Accessibility Quick Test (1 minute)
- [ ] Tab to toggle button with keyboard
- [ ] Press Enter - theme toggles
- [ ] Focus indicator is visible
- [ ] Screen reader users: check if theme change is announced

## 🎯 Common Issues to Watch For

### If you see these, report them:
1. **White text on white background** - color override missing
2. **Black text on black background** - CSS variable not defined
3. **Toggle button covers title** - positioning needs adjustment
4. **Theme doesn't persist** - localStorage issue
5. **Flash of light theme** - script loading order problem
6. **Invisible borders** - border color needs adjustment
7. **Unreadable gradients** - gradient colors need dark mode override

### Quick Fixes:
- **Hard refresh**: Ctrl+Shift+R (Cmd+Shift+R on Mac)
- **Clear cache**: If styles don't update
- **Check console**: F12 → Console tab for errors

## ⚡ Speed Test (All checks in 5 minutes)

1. Load page → Toggle works? ✓
2. Refresh → Preference saved? ✓
3. Check 3 different sections → All readable? ✓
4. Tab with keyboard → Focus visible? ✓
5. Test on mobile → Works properly? ✓

**If all ✓ = Implementation successful! 🎉**

---

## 📊 Detailed Testing (Optional - 15 minutes)

Use the comprehensive checklist in DARK_MODE_DOCUMENTATION.md for:
- Complete section-by-section testing
- Detailed accessibility verification
- Cross-browser testing
- Advanced feature testing

---

**Need help?** Check DARK_MODE_DOCUMENTATION.md for troubleshooting.
