/**
 * DataLoader - Centralized data fetching and caching
 * Handles loading all JSON files from the /data directory
 */

const DataLoader = {
    cache: {},
    
    /**
     * Generic data loader with caching
     */
    async load(filename) {
        if (this.cache[filename]) {
            return this.cache[filename];
        }
        
        try {
            const response = await fetch(`data/${filename}`);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            const data = await response.json();
            this.cache[filename] = data;
            return data;
        } catch (error) {
            console.error(`Error loading ${filename}:`, error);
            // Re-throw with more context for caller to handle
            throw new Error(`Failed to load ${filename}. ${error.message}`);
        }
    },
    
    /**
     * Load all data files
     */
    async loadAll() {
        const files = [
            'glossary.json',
            'documents.json',
            'connections.json',
            'quiz.json'
        ];
        
        const results = await Promise.all(
            files.map(file => this.load(file))
        );
        
        return {
            glossary: results[0],
            documents: results[1],
            connections: results[2],
            quiz: results[3]
        };
    },
    
    /**
     * Specific data loaders
     */
    async getGlossary() { return this.load('glossary.json'); },
    async getDocuments() { return this.load('documents.json'); },
    // NOTE: connections.json not present; method disabled to avoid confusion.
    // async getConnections() { return this.load('connections.json'); },
    async getQuiz() { return this.load('quiz.json'); },
    async getHistoricalFoundations() { return this.load('historical-foundations.json'); },
    async getHistoricalFoundationsUrls() { return this.load('historical-foundations-urls.json'); }
};

// Make DataLoader available globally
window.DataLoader = DataLoader;
